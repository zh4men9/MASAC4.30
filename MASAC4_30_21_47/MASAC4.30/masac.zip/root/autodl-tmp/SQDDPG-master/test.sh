# !/bin/bash

EXP_NAME="spread_sqddpg"

cp ./args/$EXP_NAME.py arguments.py
python -u test.py
